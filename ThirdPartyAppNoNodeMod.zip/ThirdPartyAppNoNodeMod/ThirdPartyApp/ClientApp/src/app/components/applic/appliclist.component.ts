import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: 'app-app-list',
  templateUrl: './appliclist.component.html'
})


export class ApplicListComponent {
  public applications: Application[];

  constructor(private router: Router, private http: HttpClient, @Inject('BASE_URL') private baseUrl: string) {


    http.get<Application[]>(baseUrl + 'api/application').subscribe(result => {
      this.applications = result;
    }, error => console.error(error));

  }


  onDeleteapplication(application: Application) {

    let id = application.id.toString();

    this.http.delete<Application[]>(this.baseUrl + 'api/Application/' + id).subscribe(result => {
      this.applications = result;
    }, error => console.error(error));

  }

  onExecuteApplicationProcess(application: Application) {

    let processcommand = application.command.toString();

    this.http.get<Application[]>(this.baseUrl + 'api/Application/LaunchProcess/' + processcommand).subscribe(result => {
      this.applications = result;
    }, error => console.error(error));

  }

  onCreateApplication() {
    this.router.navigate(["/question/create");
  }



}

