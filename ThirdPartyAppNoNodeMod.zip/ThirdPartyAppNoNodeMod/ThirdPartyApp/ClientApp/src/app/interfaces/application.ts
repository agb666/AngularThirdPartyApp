interface Application {
  id: number;
  name: string;
  command: string;
  buttonColour: string;
}
